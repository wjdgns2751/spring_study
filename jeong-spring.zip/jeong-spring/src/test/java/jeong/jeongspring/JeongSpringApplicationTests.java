package jeong.jeongspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JeongSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
