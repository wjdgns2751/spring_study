package jeong.jeongspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JeongSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(JeongSpringApplication.class, args);
	}

}
